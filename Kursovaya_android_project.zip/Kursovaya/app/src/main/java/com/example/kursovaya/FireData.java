package com.example.kursovaya;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FireData {
    private DatabaseReference myDatabase;
    private String SMS = "SMS";
    public FireData(){
        myDatabase = FirebaseDatabase.getInstance().getReference(SMS);
    }
    public DatabaseReference DataBase(){
        return myDatabase;
    }
}
