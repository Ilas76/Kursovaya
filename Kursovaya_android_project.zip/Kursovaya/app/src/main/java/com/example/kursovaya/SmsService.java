package com.example.kursovaya;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class SmsService extends Service {
    final String LOG_TAG = "myLogs";
    static FireData data = new FireData();
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String sms_body = intent.getExtras().getString("sms_body");

        NewSms sms = new NewSms(sms_body);
        data.DataBase().push().setValue(sms);
        return START_STICKY;
    }
}
