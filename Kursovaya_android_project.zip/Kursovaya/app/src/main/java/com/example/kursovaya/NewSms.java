package com.example.kursovaya;

public class NewSms {
    public String body;

    public NewSms(String body){
        this.body = body;
    }
}

